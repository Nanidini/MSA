﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using System.Globalization;

namespace InterviewTask
{
    class Program
    {

        public const string FilePath = @"C:\Users\navaa\Desktop\Nandini\MSA\qbank-export-1-11-2020.txt";
        public class FinancialDataItem
        {
            public string DATE { get; set; }
            public string DEBIT { get; set; }
            public string CREDIT { get; set; }
            public string PAIDTO { get; set; }
            public string PAIDBY { get; set; }
            public string DESCRIPTION { get; set; }
        }

        public class GroupedPayment
        {
            public float DEBITCOUNT { get; set; }
            public string PAIDTO { get; set; }
            public int TRANSACTIONSCOUNT { get; set; }
            

        }
        static void Main(string[] args)
        {
            List<FinancialDataItem> data = ImportFinancialData(FilePath);

            Console.WriteLine("\n------------Task 1--------------\n");


            Console.WriteLine("Grouped Payments\n");
            List<GroupedPayment> groupedPayments = GetGroupedExpenditures(data);

            Console.WriteLine("\n------------Task 2--------------\n");


            Console.WriteLine("Possible Duplicates\n");
            List<FinancialDataItem> possibleDuplicates = GetPossibleDuplicates(data);

            Console.WriteLine("\n--------------------------------");
            Console.ReadKey();
        }
 
        public static List<FinancialDataItem> ImportFinancialData(string inputPath)
        {

            // Reading text file to List Object

            var financialData = new List<FinancialDataItem>();
            var transactionsList = from row in System.IO.File.ReadLines(FilePath)
                                   let arr = row.Split('\t')
                                   select new FinancialDataItem
                                   {
                                       DATE = arr[0],
                                       DEBIT = arr[1],
                                       CREDIT = arr[2],
                                       PAIDTO = arr[3],
                                       PAIDBY = arr[4],
                                       DESCRIPTION = arr[5]
                                   };
            var credits = transactionsList.Where(x => x.CREDIT != string.Empty).ToList();
            var debits = transactionsList.Where(x => x.DEBIT != string.Empty).ToList();

            float creditsTotal = 0;
            float debitsTotal = 0;

            // Calculating total Credit as well as Debit transactions

            foreach (var c in credits)
            {
                if (c.CREDIT != "CREDIT")
                {
                    creditsTotal += float.Parse(c.CREDIT.Replace("$", ""));
                }
            }
            foreach (var d in debits)
            {
                if (d.DEBIT != "DEBIT")
                {
                    debitsTotal += float.Parse(d.DEBIT.Replace("$", ""));
                }
            }
            Console.WriteLine("Total credits: {0}\n" , creditsTotal);

            // Display all Credit and Debit Transactions 

            foreach (var c in credits)
            {
                if (c.CREDIT != "CREDIT")
                {
                    
                    Console.WriteLine("{0} Received {1} from {2} - {3}", c.DATE,c.CREDIT, c.PAIDBY, c.DESCRIPTION);
                }
            }

            Console.WriteLine("\nTotal debits: {0}\n" , debitsTotal);

            foreach (var d in debits)
            {
                if (d.DEBIT != "DEBIT")
                {
                    debitsTotal += float.Parse(d.DEBIT.Replace("$", ""));
                    Console.WriteLine("{0} PAID TO {1} from {2}", d.DATE, d.DEBIT, d.PAIDTO);
                }
            }

            return transactionsList.ToList();
        }

        //Task 1 -
        public static List<GroupedPayment> GetGroupedExpenditures(List<FinancialDataItem> data)
        {
            List<GroupedPayment> groupedPayments = new List<GroupedPayment>();

            // Grouping the List based on PAID TO data

            var result = from transaction in data
                         group transaction by transaction.PAIDTO;

            foreach (var descrip in result)
            {
                var gp = new GroupedPayment();

                float debitTotal = 0;
                var count = 0;
                var paidTo = "";
                foreach (var debit in descrip)
                {
                    paidTo = debit.PAIDTO;
                    if (debit.DEBIT != "DEBIT" && debit.DEBIT != string.Empty)
                    {
                        count++;
                        debitTotal += float.Parse(debit.DEBIT.Replace("$", ""));

                    }

                }
                if (debitTotal > 0)
                {
                    gp.PAIDTO = paidTo;
                    gp.DEBITCOUNT = debitTotal;
                    gp.TRANSACTIONSCOUNT = count;
                    groupedPayments.Add(gp);
                }
                
            }

            //Adding the grouped transactions to SortedGroupPayments List 

            int SERIALNO = 0;
            List<GroupedPayment> SortedGroupPayments = groupedPayments.OrderBy(o => o.DEBITCOUNT).Reverse().ToList();
            foreach (var SortedList in SortedGroupPayments)
            {
                SERIALNO++;
                Console.WriteLine(string.Format("{0}: ${1} in {2} payments to {3}", SERIALNO, SortedList.DEBITCOUNT, SortedList.TRANSACTIONSCOUNT, SortedList.PAIDTO));
            }
            return SortedGroupPayments;
        }

        //Task 2 - 
        public static List<FinancialDataItem> GetPossibleDuplicates(List<FinancialDataItem> data)
        {
            List<FinancialDataItem> possibleDuplicates = new List<FinancialDataItem>();

            var duplicates = new List<FinancialDataItem>();


            for (int i = 1; i < data.Count; i++)
            {
                for (int j = i + 1; j < data.Count; j++)
                {
                    //Comparing the Transaction DATE TIME to find the Duplicate Transactions

                    if ((data[i].DEBIT == data[j].DEBIT) && (data[i].PAIDTO == data[j].PAIDTO))
                    {
                        DateTime dateVal1 = DateTime.ParseExact(data[i].DATE, "dd/MM/yyyy HH:mm:ss", null);
                        DateTime dateVal2 = DateTime.ParseExact(data[j].DATE, "dd/MM/yyyy HH:mm:ss", null);
                        var test = Math.Abs(dateVal2.Subtract(dateVal1).TotalSeconds);

                        if (test < 300)
                        {
                            duplicates.Add(data[i]);
                            duplicates.Add(data[j]);
                        }
                    }
                }
            }

            foreach (var d in duplicates)
            {
                Console.WriteLine("{0} : PAID {1} to {2} {3}", d.DATE, d.DEBIT, d.PAIDTO, d.DESCRIPTION);
            }

            return duplicates;

        }
    }
}